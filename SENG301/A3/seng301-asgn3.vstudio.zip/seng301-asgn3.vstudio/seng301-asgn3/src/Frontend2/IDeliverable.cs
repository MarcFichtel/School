
namespace Frontend2 {
    public interface IDeliverable {
    }
}
